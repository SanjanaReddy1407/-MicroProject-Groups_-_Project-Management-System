# -MicroProject-Groups_-_Project-Management-System
Welcome to the Authentication and Analysis-Based Group and Project Management System. Easily create groups, assign projects, and track progress with a secure and user-friendly platform designed for students, mentors, and faculty.
